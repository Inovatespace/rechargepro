PHP EMAIL QUEUE CLASS (PHPEQ)
PHP Email Queue Class (PHPEQ) is a PHP class that is used to create and manage email queue using MYSQL database.

Add emails to databased queue.
Get emails from queue optionally filtered by category.
It uses MYSQL database for storage.
Easy to implement and all methods are commented.
It decreases page load time by eliminating real time email sending.
Instead of directly sending emails on the transactions, it is possible to insert email message to database using this class.
Emails can be processed later by setting up a cron job.
Example scripts are supplied.

Public Methods of the Queue Class

addMessage()
getEmailCount()
getEmails()
getTableName()
setConnectionDetails()
setMessageIsSent()
setTableName()
All class methods are commented.
Public Methods of the Message Class

getCategory()
getFromEmail()
getFromName()
getHeaders()
getId()
getIsSent()
getMessageHtml()
getMessagePlainText()
getSerializedHeaders()
getSubject()
getTimestampCreated()
getTimestampSent()
getToEmail()
getToName()
setCategory()
setFromEmail()
setFromName()
setHeaders()
setId()
setIsSent()
setMessageHtml()
setMessagePlainText()
setSubject()
setTimestampCreated()
setTimestampSent()
setToEmail()
All class methods are commented.
Documentation

PHP Email Queue Class (PHPEQ) comes with full documentation.
From the installation to the usage you will feel like home.

Class Requirements

PHP 5.2 and above
MySQL 5.0 and above
Folder Structure

All the class files exist in code folder. To get more information about class installation process and usage help, open index.html file from "installation and documentation" folder. "installation and documentation" folder also contains a text file ("database.txt") that contains sql statements in order to create database table structure on your mysql server.

Thanks for downloading this class! If you have improvement idea or bug fix, please feel free to contribute this class.


Ovunc Tukenmez ovunct@live.com