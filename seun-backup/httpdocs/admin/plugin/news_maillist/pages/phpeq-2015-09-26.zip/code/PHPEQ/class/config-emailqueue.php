<?php
define('CONN_HOST', 'localhost');
define('CONN_DATABASE', 'email_queue');
define('CONN_USER', 'root');
define('CONN_PASSWORD', '');