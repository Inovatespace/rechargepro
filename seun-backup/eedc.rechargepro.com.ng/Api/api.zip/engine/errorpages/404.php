<div style="margin:40px 10px; text-align:center;">

<img src="/theme/classic/images/404-error.png" width="577" height="304" />

</div>