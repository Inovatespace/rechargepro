<?php
 header("Generator: BRINQPAY API");
 header('HTTP/1.0 200" " ok');
 header("Content-Type: text/plain; charset=UTF-8");

 print_r($encode);
