<option>Banja Luka</option>
<option>Tuzla</option>
<option>Zenica</option>
<option>Bijeljina</option>
<option>Mostar</option>
<option>Prijedor</option>
<option>Brcko</option>
<option>Bihac</option>
<option>Doboj</option>