<option>Creek</option>
<option>Eastern</option>
<option>Midland</option>
<option>Stake Bay</option>
<option>Spot Bay</option>
<option>South Town</option>
<option>West End</option>
<option>Western</option>