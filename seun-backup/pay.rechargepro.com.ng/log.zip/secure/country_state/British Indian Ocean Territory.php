<option>Diego Garcia</option>
<option>Danger Island</option>
<option>Eagle Islands</option>
<option>Egmont Islands</option>
<option>Nelsons Island</option>
<option>Peros Banhos</option>
<option>Salomon Islands</option>
<option>Three Brothers</option>