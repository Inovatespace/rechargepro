<option>Boke Region</option>
<option>Conakry Region</option>
<option>Faranah Region</option>
<option>Kankan Region</option>
<option>Kindia Region</option>
<option>Labe Region</option>
<option>Mamou Region</option>
<option>Nzerekore Region</option>