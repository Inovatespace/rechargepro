<option>Alytus</option><option>Kaunas</option><option>Klaipeda</option><option>Marijampole</option><option>Panevezys</option> <option>Siauliai</option> <option>Taurage</option>
<option>TelSiai</option>
<option>Utena</option><option>Vilnius</option>