<option>Christ Church Nichola Town</option>
<option>Saint Anne Sandy Point</option>
<option>Saint George Basseterre</option>
<option>Saint John Capisterre</option>
<option>Saint Mary Cayon</option>
<option>Saint Paul Capisterre</option>
<option>Saint Peter Basseterre</option>
<option>Saint Thomas Middle Island</option>
<option>Trinity Palmetto Point</option>