<option>Reykjavik North (Reykjavikurkjordaemi Norour)</option>
<option>Reykjavik South (Reykjavikurkjordaemi Suour)</option>
<option>Northwest (Norovesturkjordaemi)</option>
<option>Northeast (Noroausturkjordaemi)</option>
<option>South (Suourkjordaemi)</option>
<option>Southwest (Suovesturkjordaemi)</option>