<option>Kolofo'ou</option>
<option>Kolomotu'a</option>
<option>Vaini</option>
<option>Tatakamotonga</option>
<option>Lapaha</option>
<option>Nukunuku</option>
<option>Kolovai</option>
<option>Neiafu</option>
<option>Pangaimotu</option>
<option>Hahake</option>
<option>Leimatu'a</option>
<option>Hihifo</option>
<option>Motu</option>
<option>Ofu</option>
<option>Pangai</option>
<option>Foa</option>
<option>Lulunga</option>
<option>Mu'omu'a</option>
<option>Ha'ano</option>
<option>'Uiha</option>
<option>'Eua Motu'a</option>
<option>'Eua Fo'ou</option>
<option>Niua Toputapu</option>
<option>Niua Fo'ou</option>
