<option>Mauritius</option>
<option>Rodrigues</option>
<option>Agalega</option>
<option>Tromelin</option>
<option>Cargados Carajos</option>
<option>Chagos Archipelago</option>
<option>Diego Garcia</option>