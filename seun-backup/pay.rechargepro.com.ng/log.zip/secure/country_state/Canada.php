<option>Ontario</option>
<option>Quebec</option>
<option>Nova Scotia</option>
<option>New Brunswick</option>
<option>Manitoba</option>
<option>British Columbia</option>
<option>Prince Edward Island</option>
<option>Saskatchewan</option>
<option>Alberta</option>
<option>Newfoundland and Labrador</option>
<option>Northwest Territories</option>
<option>Yukon</option>
<option>Nunavut</option>