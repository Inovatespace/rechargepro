<option>Boucle du Mouhoun</option>
<option>Cascades</option>
<option>Centre</option>
<option>Centre-Est</option>
<option>Centre-Nord</option>
<option>Centre-Ouest</option>
<option>Centre-Sud</option>
<option>Est</option>
<option>Hauts-Bassins</option>
<option>Nord</option>
<option>Plateau-Central</option>
<option>Sahel</option>
<option>Sud-Ouest</option>