 <option>Autonomous City of Buenos Aires</option>
 <option>Buenos Aires Province</option>
 <option>Catamarca</option>
 <option>Chaco</option>
 <option>Chubut</option>
 <option>Cordoba</option>
 <option>Corrientes</option>
 <option>Entre Rios</option>
 <option>Formosa</option>
 <option>Jujuy</option>
 <option>La Pampa</option>
 <option>La Rioja</option>
 <option>Mendoza</option>
 <option>Misiones</option>
 <option>Neuquen</option>
 <option>Rio Negro</option>
 <option>Salta</option>
 <option>San Juan</option>
 <option>San Luis</option>
 <option>Santa Cruz</option>
 <option>Santa Fe</option>
 <option>Santiago del Estero</option>
 <option>Tierra del Fuego, Antartida e Islas del Atlantico Sur</option>
 <option>Tucuman</option>