<option>Mwali</option>
<option>Ngazidja</option>
<option>Nzwani</option>
<option>Mahore</option>