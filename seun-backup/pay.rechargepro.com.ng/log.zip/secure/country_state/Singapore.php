<option>Central Singapore Community Development Council</option>
<option>North East Community Development Council</option>
<option>North West Community Development Council</option>
<option>South East Community Development Council</option>
<option>South West Community Development Council</option>