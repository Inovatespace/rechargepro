<option>Famagusta</option>   
<option>Kyrenia</option><option>Larnaca</option><option>Lemesos</option><option>Nicosia</option><option>Paphos</option>