<option>Direction Island</option>
<option>Home Island</option>
<option>Horsburgh Island</option>
<option>South Island</option>
<option>West Island</option>