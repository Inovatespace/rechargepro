<option>Beni</option>
<option>Chuquisaca</option>
<option>Cochabamba</option>
<option>La Paz</option>
<option>Oruro</option>
<option>Pando</option>
<option>Potosi</option>
<option>Santa Cruz</option>
<option>Tarija</option>