<option>Province</option>
<option>Bandundu</option><option>Bas-Congo</option><option>equateur</option><option>Kasai-Occidental</option><option>Kasai-Oriental</option><option>Katanga</option><option>Kinshasa (city-province)</option>
<option>Maniema</option><option>Nord-Kivu</option><option>Orientale</option><option>Sud-Kivu</option>