<option>Aitutaki</option>
<option>Atiu</option>
<option>Manuae</option>
<option>Mangaia</option>
<option>Manihiki</option>
<option>Mitiaro</option>
<option>Mauke</option>
<option>Nassau Island</option>
<option>Palmerston</option>
<option>Penrhyn</option>
<option>Pukapuka</option>
<option>Rakahanga</option>
<option>Rarotonga</option>
<option>Surwarrow</option>
<option>Takutea</option>