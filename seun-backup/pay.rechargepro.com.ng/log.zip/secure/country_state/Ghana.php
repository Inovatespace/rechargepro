<option>Ashanti Region (Kumasi)</option>
<option>Brong-Ahafo Region (Sunyani)</option>
<option>Central Region (Cape Coast)</option>
<option>Eastern Region (Koforidua)</option>
<option>Greater Accra Region (Accra)</option>
<option>Northern Region (Tamale)</option>
<option>Upper East Region (Bolgatanga)</option>
<option>Upper West Region (Wa)</option>
<option>Volta Region (Ho)</option>
<option>Western Region (Sekondi-Takoradi)</option>