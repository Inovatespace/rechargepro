<option>Andrijevica</option>
<option>Bar</option>
<option>Berane</option>
<option>Bijelo Polje</option>
<option>Budva</option>
<option>Cetinje</option>
<option>Danilovgrad</option>
<option>Herceg Novi</option>
<option>KolaSin</option>
<option>Kotor</option>
<option>Mojkovac</option>
<option>NikSic</option>
<option>Plav</option>
<option>Pluzine</option>
<option>Pljevlja</option>
<option>Podgorica</option>
<option>Rozaje</option>
<option>Savnik</option>
<option>Tivat</option>
<option>Ulcinj</option>
<option>zabljak</option>