<option>Simbu</option>
<option>Eastern Highlands</option>
<option>Enga</option>
<option>Hela</option>
<option>Jiwaka</option>
<option>Southern Highlands</option>
<option>Western Highlands</option>
<option>East New Britain</option>
<option>Manus</option>
<option>New Ireland</option>
<option>North Solomons (Bougainville)</option>
<option>West New Britain</option>
<option>East Sepik</option>
<option>Madang</option>
<option>Morobe</option>
<option>West Sepik (Sandaun)</option>
<option>Central</option>
<option>Gulf</option>
<option>Milne Bay</option>
<option>Northern Province (Oro)</option>
<option>Western (Fly)</option>
<option>National Capital District</option>

