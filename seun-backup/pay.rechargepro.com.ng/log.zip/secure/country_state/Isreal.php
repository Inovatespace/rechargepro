<option>Jerusalem District</option>
<option>Northern District</option>
<option>Haifa District</option>
<option>Central District</option>
<option>Tel Aviv District</option>
<option>Southern District</option>