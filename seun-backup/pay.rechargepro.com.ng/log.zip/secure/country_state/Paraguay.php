<option>Concepcion</option>
<option>San Pedro</option>
<option>Cordillera</option>
<option>Guaira</option>
<option>CaaguazU</option>
<option>Caazapa</option>
<option>ItapUa</option>
<option>Misiones</option>
<option>Paraguari</option>
<option>Alto Parana</option>
<option>Central</option>
<option>neembucU</option>
<option>Amambay</option>
<option>CanindeyU</option>
<option>Presidente Hayes</option>
<option>Alto Paraguay</option>
<option>Boqueron</option>
<option>Distrito Capital</option>