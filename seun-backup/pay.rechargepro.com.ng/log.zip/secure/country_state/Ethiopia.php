<option>Addis Ababa</option>
<option>Afar</option>
<option>Amhara</option>
<option>Benishangul-Gumuz</option>
<option>Dire Dawa</option>
<option>Gambela</option>
<option>Harari</option>
<option>Oromia</option>
<option>Somali</option>
<option>Southern Nations, Nationalities, and People's Region</option>
<option>Tigray</option>