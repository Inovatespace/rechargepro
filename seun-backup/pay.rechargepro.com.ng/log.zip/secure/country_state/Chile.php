<option>Arica and Parinacota</option>
<option>Tarapaca</option>
<option>Antofagasta</option>
<option>Atacama</option>
<option>Coquimbo</option>
<option>Valparaiso</option>
<option>O'Higgins</option>
<option>Maule</option>
<option>Biobio</option>
<option>Araucania</option>
<option>Los Rios</option>
<option>Los Lagos</option>
<option>Aisen</option>
<option>Magallanes and Antartica Chilena</option>
<option>Santiago Metropolitan</option>
