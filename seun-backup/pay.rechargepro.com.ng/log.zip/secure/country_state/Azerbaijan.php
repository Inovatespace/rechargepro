<option>Absheron</option>
<option>Aran</option>
<option>Daghlig Shirvan</option>
<option>Ganja-Gazakh</option>
<option>Guba-Khachmaz</option>
<option>Kalbajar-Lachin</option>
<option>Lankaran</option>
<option>Nakhchivan</option>
<option>Shaki-Zaqatala</option>
<option>Yukhari Garabakh</option>