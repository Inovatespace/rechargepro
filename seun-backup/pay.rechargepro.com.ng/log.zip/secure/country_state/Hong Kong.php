Islands</option>Kwai Tsing</option>North</option>Sai Kung</option>Sha Tin</option>Tai Po</option>Tsuen Wan</option>Tuen Mun</option>Yuen Long</option>
Sham Shui Po</option>Kowloon City</option>Kwun Tong</option>Wong Tai Sin</option>Yau Tsim Mong</option>
Central and Western</option>Eastern</option>Southern</option>Wan Chai</option>