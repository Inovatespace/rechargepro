<option>Northern Province</option>
<option>Eastern Province</option>
<option>Southern Province</option>
<option>Western Province</option>
<option>Kigali Province</option>