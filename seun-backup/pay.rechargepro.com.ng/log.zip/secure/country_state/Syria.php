<option>Latakia</option>
<option>Idlib</option>
<option>Aleppo</option>
<option>Tartus</option>
<option>Hama</option>
<option>Ar-Raqqah</option>
<option>Al-Hasakah</option>
<option>Deir ez-Zor</option>
<option>Homs</option>
<option>Rif Dimashq</option>
<option>Quneitra</option>
<option>Daraa</option>
<option>As-Suwayda</option>
<option>Damascus</option>