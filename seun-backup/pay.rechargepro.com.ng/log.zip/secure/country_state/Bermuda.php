<option>Devonshire</option>
<option>Hamilton</option>
<option>Paget</option>
<option>Pembroke</option>
<option>St George's</option>
<option>Sandys</option>
<option>Smith's</option>
<option>Southampton</option>
<option>Warwick</option>
<option>Hamilton</option>
<option>St George</option>