<option>Awdal</option>
<option>Bakool</option>
<option>Banaadir</option>
<option>Bari</option>
<option>Bay</option>
<option>Galguduud</option>
<option>Gedo</option>
<option>Hiiraan</option>
<option>Middle Juba</option>
<option>Lower Juba</option>
<option>Mudug</option>
<option>Nugaal</option>
<option>Sanaag</option>
<option>Middle Shabele</option>
<option>Lower Shabele</option>
<option>Sool</option>
<option>Togdheer</option>
<option>Woqooyi Galbeed</option>