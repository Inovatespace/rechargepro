<option>Bishkek</option>
<option>Batken</option>
<option>Chuy</option>
<option>Jalal-Abad</option>
<option>Naryn</option>
<option>Osh</option>
<option>Talas</option>
<option>Issyk Kul</option>
<option>Osh(Shaar)</option>