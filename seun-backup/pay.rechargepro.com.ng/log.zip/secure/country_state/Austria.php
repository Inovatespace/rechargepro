<option>Burgenland</option>
<option>Carinthia (Karnten)</option>
<option>Lower Austria (Niederosterreich)</option>
<option>Upper Austria (Oberosterreich)</option>
<option>Salzburg</option>
<option>Styria (Steiermark)</option>
<option>Tyrol (Tirol)</option>
<option>Vorarlberg</option>
<option>Vienna (Wien)</option>