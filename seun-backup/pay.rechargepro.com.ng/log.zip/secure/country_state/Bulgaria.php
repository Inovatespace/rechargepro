<option>Blagoevgrad</option>
<option>Burgas</option>
<option>Dobrich</option>
<option>Gabrovo</option>
<option>Haskovo</option>
<option>Kardzhali</option>
<option>Kyustendil</option>
<option>Lovech</option>
<option>Montana</option>
<option>Pazardzhik</option>
<option>Pernik</option>
<option>Pleven</option>
<option>Plovdiv</option>
<option>Razgrad</option>
<option>Rousse</option>
<option>Shumen</option>
<option>Silistra</option>
<option>Sliven</option>
<option>Smolyan</option>
<option>Sofia Province</option>
<option>Stara Zagora</option>
<option>Targovishte</option>
<option>Varna</option>
<option>Veliko Tarnovo</option>
<option>Vidin</option>
<option>Vratsa</option>
<option>Yambol</option>