<option>Andorra la Vella</option>
<option>Canillo</option>
<option>Encamp</option>
<option>Escaldes-Engordany</option>
<option>La Massana</option>
<option>Ordino</option>
<option>Sant Julia de Loria</option>