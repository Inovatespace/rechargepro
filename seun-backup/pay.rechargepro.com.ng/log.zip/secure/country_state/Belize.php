<option>Belize</option>
<option>Cayo</option>
<option>Corozal</option>
<option>Orange</option>
<option>Stann</option>
<option>Toledo</option>
