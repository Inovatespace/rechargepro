<option>Il-Kunsill Lokali tal-Belt Valletta</option>
<option>Il-Kunsill Lokali tal-Imdina</option>
<option>Il-Kunsill Lokali tal-Birgu</option>
<option>Il-Kunsill Lokali tal-Isla</option>
<option>Il-Kunsill Lokali ta' Bormla</option>
<option>Il-Kunsill Lokali ta' Hal Qormi</option>
<option>Il-Kunsill Lokali ta' Haz-Zebbug</option>
<option>Il-Kunsill Lokali tas-Siggiewi</option>
<option>Il-Kunsill Lokali ta' Haz-Zabbar</option>
<option>Il-Kunsill Lokali taz-Zejtun</option>
<option>Il-Kunsill Lokali tar-Rabat, Ghawdex</option>
<option>Il-Kunsill Lokali ta' H'Attard</option>
<option>Il-Kunsill Lokali ta' Hal Balzan</option>
<option>Il-Kunsill Lokali ta' Birkirkara</option>
<option>Il-Kunsill Lokali ta' Birzebbuga</option>
<option>Il-Kunsill Lokali ta' Had-Dingli</option>
<option>Il-Kunsill Lokali tal-Fgura</option>
<option>Il-Kunsill Lokali tal-Furjana</option>
<option>Il-Kunsill Lokali tal-Fontana</option>
<option>Il-Kunsill Lokali t'Ghajnsielem</option>
<option>Il-Kunsill Lokali tal-Gharb</option>
<option>Il-Kunsill Lokali ta' Hal Gharghur</option>
<option>Il-Kunsill Lokali tal-Ghasri</option>
<option>Il-Kunsill Lokali ta' Hal Ghaxaq</option>
<option>Il-Kunsill Lokali tal-Gudja</option>
<option>Il-Kunsill Lokali tal-Gzira</option>
<option>Il-Kunsill Lokali tal-Hamrun</option>
<option>Il-Kunsill Lokali tal-Iklin</option>
<option>Il-Kunsill Lokali tal-Kalkara</option>
<option>Il-Kunsill Lokali Ta' Kercem</option>
<option>Il-Kunsill Lokali ta' Hal Kirkop</option>
<option>Il-Kunsill Lokali ta' Hal Lija</option>
<option>Il-Kunsill Lokali ta' Hal Luqa</option>
<option>Il-Kunsill Lokali tal-Marsa</option>
<option>Il-Kunsill Lokali ta' Marsaskala</option>
<option>Il-Kunsill Lokali ta' Marsaxlokk</option>
<option>Il-Kunsill Lokali tal-Mellieha</option>
<option>Il-Kunsill Lokali tal-Imgarr</option>
<option>Il-Kunsill Lokali tal-Mosta</option>
<option>Il-Kunsill Lokali tal-Imqabba</option>
<option>Il-Kunsill Lokali tal-Imsida</option>
<option>Il-Kunsill Lokali tal-Imtarfa</option>
<option>Il-Kunsill Lokali tal-Munxar</option>
<option>Il-Kunsill Lokali tan-Nadur</option>
<option>Il-Kunsill Lokali tan-Naxxar</option>
<option>Il-Kunsill Lokali ta' Rahal Gdid</option>
<option>Il-Kunsill Lokali ta' Pembroke</option>
<option>Il-Kunsill Lokali Tal-Pieta</option>
<option>Il-Kunsill Lokali tal-Qala</option>
<option>Il-Kunsill Lokali tal-Qrendi</option>
<option>Il-Kunsill Lokali tar-Rabat</option>
<option>Il-Kunsill Lokali ta' Hal Safi</option>
<option>Il-Kunsill Lokali ta' San Giljan</option>
<option>Il-Kunsill Lokali ta' San Gwann</option>
<option>Il-Kunsill Lokali ta' San Lawrenz</option>
<option>Il-Kunsill Lokali ta' San Pawl il-Bahar</option>
<option>Il-Kunsill Lokali Ta' Sannat</option>
<option>Il-Kunsill Lokali ta' Santa Lucija</option>
<option>Il-Kunsill Lokali ta' Santa Venera</option>
<option>Il-Kunsill Lokali ta' Tas-Sliema</option>
<option>Il-Kunsill Lokali tas-Swieqi</option>
<option>Il-Kunsill Lokali ta' Hal Tarxien</option>
<option>Il-Kunsill Lokali ta' Ta' Xbiex</option>
<option>Il-Kunsill Lokali tax-Xaghra</option>
<option>Il-Kunsill Lokali tax-Xewkija</option>
<option>Il-Kunsill Lokali tax-Xghajra</option>
<option>Il-Kunsill Lokali taz-Zebbug, Ghawdex</option>
<option>Il-Kunsill Lokali taz-Zurrieq</option>