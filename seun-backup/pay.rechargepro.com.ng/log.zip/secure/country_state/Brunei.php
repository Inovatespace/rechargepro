<option>Sengkurong</option>
<option>Gadong A & Gadong B</option>
<option>Berakas A</option>
<option>Kuala Belait</option>
<option>Seria</option>
<option>Berakas B</option>
<option>Sungai Liang</option>
<option>Pengkalan Batu</option>
<option>Kilanas</option>
<option>Kota Batu</option>
<option>Pekan Tutong</option>
<option>Mentiri</option>
<option>Serasa</option>
<option>Kianggeh</option>
<option>Burong Pinggai Ayer</option>
<option>Keriam</option>
<option>Lumapas</option>
<option>Kiudang</option>
<option>Saba</option>
<option>Sungai Kedayan</option>