<option>Pinar del Rio</option>
<option>Artemisa</option>
<option>La Habana</option>
<option>Mayabeque</option>
<option>Matanzas</option>
<option>Cienfuegos</option>
<option>Villa Clara</option>
<option>Sancti Spiritus</option>
<option>Ciego de avila</option>
<option>Camaguey</option>
<option>Las Tunas</option>
<option>Granma</option>
<option>Holguin</option>
<option>Santiago de Cuba</option>
<option>Guantanamo</option>
<option>Isla de la Juventud</option>