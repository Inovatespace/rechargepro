<option>Ariana</option>
<option>Beja</option>
<option>Ben Arous</option>
<option>Bizerte</option>
<option>Gabes</option>
<option>Gafsa</option>
<option>Jendouba</option>
<option>Kairouan</option>
<option>Kasserine</option>
<option>Kebili</option>
<option>Kef</option>
<option>Mahdia</option>
<option>Manouba</option>
<option>Medenine</option>
<option>Monastir</option>
<option>Nabeul</option>
<option>Sfax</option>
<option>Sidi Bouzid</option>
<option>Siliana</option>
<option>Sousse</option>
<option>Tataouine</option>
<option>Tozeur</option>
<option>Tunis</option>
<option>Zaghouan</option>