<option>Hanover</option><option>Saint Elizabeth</option><option>Saint James</option><option>Trelawny</option><option>Westmoreland</option>
<option>Clarendon</option><option>Manchester</option><option>Saint Ann</option><option>Saint Catherine</option><option>Saint Mary</option>
<option>Kingston</option><option>Portland</option><option>Saint Andrew</option><option>Saint Thomas</option>