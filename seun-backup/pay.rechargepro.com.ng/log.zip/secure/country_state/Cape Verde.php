<option>Santo Antao</option>
<option>Sao Vicente</option>
<option>Santa Luzia</option>
<option>Sao Nicolau</option>
<option>Sal</option>
<option>Boa Vista</option>
<option>Maio</option>
<option>Santiago</option>
<option>Fogo</option>
<option>Brava</option>
