<option>Region d'Ali Sabieh</option>
<option>Region d'Arta</option>
<option>Region de Dikhil</option>
<option>Ville de Djibouti</option>
<option>Region d'Obock</option>
<option>Region de Tadjourah</option>