<option>Hovedstaden</option>
<option>Midtjylland</option>
<option>Nordjylland</option>
<option>Sjaelland</option>
<option>Syddanmark</option>
