<option>Antwerp</option>
<option>East Flanders</option>
<option>Flemish Brabant</option>
<option>Hainaut</option>
<option>Liege</option>
<option>Limburg</option>
<option>Luxembourg</option>
<option>Namur</option>
<option>Walloon Brabant</option>
<option>West Flanders</option>