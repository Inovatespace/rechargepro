<option>Aragatsotn</option>
<option>Ararat</option>
<option>Armavir</option>
<option>Gegharkunik</option>
<option>Kotayk</option>
<option>Lori</option>
<option>Shirak</option>
<option>Syunik</option>
<option>Tavush</option>
<option>Vayots Dzor</option>
<option>Yerevan</option>