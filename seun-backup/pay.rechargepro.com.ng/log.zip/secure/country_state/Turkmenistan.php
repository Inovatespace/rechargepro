<option>Ashgabat City</option>
<option>Ahal Province</option><option>Balkan Province</option><option>Dasoguz Province</option><option>Lebap Province</option><option>Mary Province</option>