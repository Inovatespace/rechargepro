<option>Aguascalientes</option>
<option>Baja California</option>
<option>Baja California Sur</option>
<option>Campeche</option>
<option>Chiapas</option>
<option>Chihuahua</option>
<option>Coahuila de Zaragoza</option>
<option>Colima</option>
<option>Durango</option>
<option>Guanajuato</option>
<option>Guerrero</option>
<option>Hidalgo</option>
<option>Jalisco</option>
<option>Mexico</option>
<option>Michoacan de Ocampo</option>
<option>Morelos</option>
<option>Nayarit</option>
<option>Nuevo Leon</option>
<option>Oaxaca</option>
<option>Puebla</option>
<option>Queretaro de Arteaga</option>
<option>Quintana Roo</option>
<option>San Luis Potosi</option>
<option>Sinaloa</option>
<option>Sonora</option>
<option>Tabasco</option>
<option>Tamaulipas</option>
<option>Tlaxcala</option>
<option>Veracruz de</option>
<option>Ignacio de la Llave</option>
<option>Yucatan</option>
<option>Zacatecas</option>