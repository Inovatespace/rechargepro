<option>Acre</option>
<option>Alagoas</option>
<option>Amapa</option>
<option>Amazonas</option>
<option>Bahia</option>
<option>Ceara</option>
<option>Distrito Federal</option>
<option>Espirito Santo</option>
<option>Goias</option>
<option>Maranhao</option>
<option>Mato Grosso</option>
<option>Mato Grosso do Sul</option>
<option>Minas Gerais</option>
<option>Para</option>
<option>Paraiba</option>
<option>Parana</option>
<option>Pernambuco</option>
<option>Piaui</option>
<option>Rio de Janeiro</option>
<option>Rio Grande do Norte</option>
<option>Rio Grande do Sul</option>
<option>Rondonia</option>
<option>Roraima</option>
<option>Santa Catarina</option>
<option>Sao Paulo</option>
<option>Sergipe</option>
<option>Tocantins</option>