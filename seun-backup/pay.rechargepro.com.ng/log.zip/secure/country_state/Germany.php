<option>Baden-Wurttemberg</option>
<option>Bavaria (Bayern)</option>
<option>Berlin</option>
<option>Brandenburg</option>
<option>Bremen (Freie Hansestadt Bremen)</option>
<option>Hamburg</option>
<option>Hesse (Hessen)</option>
<option>Mecklenburg-Vorpommern</option>
<option>Lower Saxony (Niedersachsen)</option>
<option>North Rhine-Westphalia (Nordrhein-Westfalen)</option>
<option>Rhineland-Palatinate (Rheinland-Pfalz)</option>
<option>Saarland</option>
<option>Saxony (Sachsen)</option>
<option>Saxony-Anhalt (Sachsen-Anhalt)</option>
<option>Schleswig-Holstein</option><option>Thuringia (Thuringen)</option>