<option>Beirut</option>
<option>Baabda</option>
<option>Tripoli</option>
<option>Zahleh</option>
<option>Nabatiye</option>
<option>Sidon</option>