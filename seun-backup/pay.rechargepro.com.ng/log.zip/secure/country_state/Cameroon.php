<option>Adamawa</option>
<option>Centre</option>
<option>East</option>
<option>Far North</option>
<option>Littoral</option>
<option>North</option>
<option>Northwest</option>
<option>South</option>
<option>Southwest</option>
<option>West</option>