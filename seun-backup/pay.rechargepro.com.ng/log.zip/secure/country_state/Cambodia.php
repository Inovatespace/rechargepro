<option>Banteay Meanchey</option>
<option>Battambang</option>
<option>Kampong Cham</option>
<option>Kampong Chhnang</option>
<option>Kampong Speu</option>
<option>Kampong Thom</option>
<option>Kampot</option>
<option>Kandal</option>
<option>Kep</option>
<option>Koh Kong</option>
<option>Kratie</option>
<option>Mondulkiri</option>
<option>Oddar Meanchey</option>
<option>Pailin</option>
<option>Phnom Penh</option>
<option>Preah Sihanouk</option>
<option>Preah Vihear</option>
<option>Pursat</option>
<option>Prey Veng</option>
<option>Ratanakiri</option>
<option>Siem Reap</option>
<option>Stung Treng</option>
<option>Svay Rieng</option>
<option>Takeo</option>