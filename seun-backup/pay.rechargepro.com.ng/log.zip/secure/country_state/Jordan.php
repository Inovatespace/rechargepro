<option>Irbid</option><option>Mafraq</option><option>Jarash</option><option>Ajloun</option>
<option>Amman</option><option>Balqa</option><option>Zarqa</option><option>Madaba</option>
<option>Karak</option><option>Tafilah</option><option>Ma'an</option><option>Aqaba</option>