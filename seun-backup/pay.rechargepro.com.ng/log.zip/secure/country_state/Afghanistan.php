<option>Badakhshan</option>
<option>Badghis</option>
<option>Baghlan</option>
<option>Balkh</option>
<option>Bamyan</option>
<option>Daykundi</option>
<option>Farah</option>
<option>Faryab</option>
<option>Ghazni</option>
<option>Ghor</option>
<option>Helmand</option>
<option>Herat</option>
<option>Jowz jan</option>
<option>Kabul</option>
<option>Kandahar</option>
<option>Kapisa</option>
<option>Khost</option>
<option>Kunar</option>
<option>Kunduz</option>
<option>Laghman</option>
<option>Logar</option>
<option>Maidan Wardak</option>
<option>Nangarhar</option>
<option>Nimruz</option>
<option>Nuristan</option>
<option>Paktia</option>
<option>Paktika</option>
<option>Panjshir</option>
<option>Parwan</option>
<option>Samangan</option>
<option>Sar-e Pol</option>
<option>Takhar</option>
<option>Urozgan</option>
<option>Zabul</option>