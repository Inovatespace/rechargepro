<option>Division</option>
<option>Seoul</option><option>Sejong</option><option>Busan</option><option>Incheon</option><option>Daegu</option><option>Gwangju</option><option>Daejeon</option><option>Ulsan</option><option>Gyeonggi Province</option><option>Gangwon Province</option><option>North Chungcheong Province (Chungbuk Province)</option>
<option>South Chungcheong Province (Chungnam Province)</option>
<option>North Jeolla Province (Jeonbuk Province)</option>
<option>South Jeolla Province (Jeonnam Province)</option>
<option>North Gyeongsang Province (Gyeongbuk Province)</option>
<option>South Gyeongsang Province (Gyeongnam Province)</option>
<option>Jeju Province</option>