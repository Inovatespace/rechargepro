<option>Cabo Delgado</option>
<option>Gaza</option>
<option>Inhambane</option>
<option>Manica</option>
<option>Maputo City</option>
<option>Maputo</option>
<option>Nampula</option>
<option>Niassa</option>
<option>Sofala</option>
<option>Tete</option>
<option>Zambezia</option>