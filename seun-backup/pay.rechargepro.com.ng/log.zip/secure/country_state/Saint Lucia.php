<option>Anse la Raye</option>
<option>Castries</option>
<option>Choiseul</option>
<option>Dauphin</option>
<option>Dennery</option>
<option>Gros Islet</option>
<option>Laborie</option>
<option>Micoud</option>
<option>Praslin</option>
<option>Soufriere</option>
<option>Vieux Fort</option>