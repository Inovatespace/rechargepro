<option>Leinster</option>
<option>Munster</option>
<option>Connacht</option>
<option>Ulster</option>