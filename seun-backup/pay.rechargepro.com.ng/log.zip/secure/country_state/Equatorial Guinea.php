<option>Annobon</option>
<option>Bioko Norte</option>
<option>Bioko Sur</option>
<option>Centro Sur</option>
<option>Kie-Ntem</option>
<option>Litoral</option>
<option>Wele-Nzas</option>