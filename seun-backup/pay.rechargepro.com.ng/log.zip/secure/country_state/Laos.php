<option>Attapu</option>
<option>Bokeo</option>
<option>Bolikhamxai</option>
<option>Champasak</option>
<option>Houaphan</option>
<option>Khammouan</option>
<option>Louang Namtha</option>
<option>Louangphabang</option>
<option>Oudomxai</option>
<option>Phongsali</option>
<option>Sainyabuli</option>
<option>Salavan</option>
<option>Savannakhet</option>
<option>Sekong</option>
<option>Vientiane Prefecture</option>
<option>Vientiane</option>
<option>Xiangkhoang</option>