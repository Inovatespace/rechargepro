<option>Al Jazirah</option>
<option>Blue Nile</option>
<option>Sennar</option>
<option>White Nile</option>
<option>Central Darfur</option>
<option>East Darfur</option>
<option>North Darfur</option>
<option>South Darfur</option>
<option>West Darfur</option>
<option>Kassala</option>
<option>Al Qadarif</option>
<option>Red Sea</option>
<option>Khartoum</option>
<option>North Kurdufan</option>
<option>South Kurdufan</option>
<option>Northern</option>
<option>River Nile</option>
