<option>Banaba</option>
<option>Tarawa</option>
<option>Northern Gilbert Islands</option>
<option>Central Gilbert Island</option>
<option>Southern Gilbert Islands</option>
<option>Line Islands</option>