<option>Doha (Ad Dawhah)</option>
<option>Al Ghuwariyah</option>
<option>Al Jumaliyah</option>
<option>Al Khawr</option>
<option>Al Wakrah</option>
<option>Ar Rayyan</option>
<option>Jariyan al Batnah</option>
<option>Madinat ash Shamal</option>
<option>Umm Salal</option>
<option>Mesaieed</option>