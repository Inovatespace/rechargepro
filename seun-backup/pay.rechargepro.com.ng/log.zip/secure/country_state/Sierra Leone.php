<option>Eastern Province</option>
<option>Northern Province</option>
<option>Southern Province</option>
<option>Western Area</option>