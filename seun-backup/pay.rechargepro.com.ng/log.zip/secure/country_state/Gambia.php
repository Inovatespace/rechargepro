<option>Lower River (Mansa Konko)</option>
<option>Central River (Janjanbureh)</option>
<option>North Bank (Kerewan)</option>
<option>Upper River (Basse)</option>
<option>Western (Brikama)</option>
<option>Banjul (North, Central, South)</option>