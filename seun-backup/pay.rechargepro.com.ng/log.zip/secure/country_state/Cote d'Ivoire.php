<option>Agneby</option>
<option>Bafing</option>
<option>Bas-Sassandra</option>
<option>Denguele</option>
<option>Dix-Huit Montagnes</option>
<option>Fromager</option>
<option>Haut-Sassandra</option>
<option>Lacs</option>
<option>Lagunes</option>
<option>Marahoue</option>
<option>Moyen-Cavally</option>
<option>Moyen-Comoe</option>
<option>N'zi-Comoe</option>
<option>Savanes</option>
<option>Sud-Bandama</option>
<option>Sud-Comoe</option>
<option>Vallee du Bandama</option>
<option>Worodougou</option>
<option>Zanzan</option>