<option>?a'il</option><option>Qaaim</option><option>Riyad</option>
<option>Tabuk</option><option>Madinah</option><option>Makkah</option><option>Bahah</option>
<option>Northern Borders</option><option>Jawf</option>
<option>Jizan</option><option>`Asir</option><option>Najran</option>
<option>Eastern Province</option>