<option>Australian Capital Territory</option>
<option>New South Wales</option>
<option>Victoria</option>
<option>Queensland</option>
<option>South Australia</option>
<option>Western Australia</option>
<option>Tasmania</option>
<option>Northern Territory</option>
<option>Norfolk Island</option>
<option>Christmas Island</option>
<option>Cocos Island</option>
<option>Australian Antarctic Territory</option>
<option>Macquarie Island</option>
