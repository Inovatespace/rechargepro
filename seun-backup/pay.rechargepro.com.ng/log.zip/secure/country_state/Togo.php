<option>Centrale</option>
<option>Kara</option>
<option>Maritime</option>
<option>Plateaux</option>
<option>Savanes</option>