<option>Upper North Province</option>
<option>North Province</option>
<option>North Central Province</option>
<option>Central Province</option>
<option>South Central Province</option>
<option>Upper South Province</option>
<option>South Province</option>