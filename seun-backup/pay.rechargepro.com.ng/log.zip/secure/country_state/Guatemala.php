<option>Alta Verapaz</option>
<option>Baja Verapaz</option>
<option>Chimaltenango</option>
<option>Chiquimula</option>
<option>Peten</option>
<option>El Progreso</option>
<option>El Quiche</option>
<option>Escuintla</option>
<option>Guatemala</option>
<option>Huehuetenango</option>
<option>Izabal</option>
<option>Jalapa</option>
<option>Jutiapa</option>
<option>uetzaltenango</option>
<option>Retalhuleu</option>
<option>Sacatepequez</option>
<option>San Marcos</option>
<option>Santa Rosa</option>
<option>Solola</option>
<option>Suchitepequez</option>
<option>Totonicapan</option>
<option>Zacapa</option>