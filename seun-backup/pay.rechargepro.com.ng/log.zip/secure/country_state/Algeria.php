<option>Adrar</option>
<option>Chlef</option>
<option>Laghouat</option>
<option>Oum El Bouaghi</option>
<option>Batna</option>
<option>Bejaia</option>
<option>Biskra</option>
<option>Bechar</option>
<option>Blida</option>
<option>Bouira</option>
<option>Tamanrasset</option>
<option>Tebessa</option>
<option>Tlemcen</option>
<option>Tiaret</option>
<option>Tizi Ouzou</option>
<option>Algiers</option>
<option>Djelfa</option>
<option>Jijel</option>
<option>Setif</option>
<option>Saida</option>
<option>Skikda</option>
<option>Sidi Bel Abbes</option>
<option>Annaba</option>
<option>Guelma</option>
<option>Constantine</option>
<option>Medea</option>
<option>Mostaganem</option>
<option>M'Sila</option>
<option>Mascara</option>
<option>Ouargla</option>
<option>Oran</option>
<option>El Bayadh</option>
<option>Illizi</option>
<option>Bordj Bou Arreridj</option>
<option>Boumerdes</option>
<option>El Taref</option>
<option>Tindouf</option>
<option>Tissemsilt</option>
<option>El Oued</option>
<option>Khenchela</option>
<option>Souk Ahras</option>
<option>Tipaza</option>
<option>Mila</option>
<option>Ain Defla</option>
<option>Naama</option>
<option>Ain Timouchent</option>
<option>Ghardaia</option>
<option>Relizane</option>