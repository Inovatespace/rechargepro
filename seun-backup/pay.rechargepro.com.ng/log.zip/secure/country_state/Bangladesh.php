<option>Barisal</option>
<option>Chittagong</option>
<option>Dhaka</option>
<option>Khulna</option>
<option>Rajshahi</option>
<option>Rangpur</option>
<option>Sylhet</option>