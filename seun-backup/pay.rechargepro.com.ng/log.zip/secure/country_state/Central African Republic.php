<option>Bamingui-Bangoran</option>
<option>Basse-Kotto</option><option>Haute-Kotto</option><option>Haut-Mbomou</option><option>Kemo</option><option>Lobaye</option><option>Mambere-Kadei</option>
<option>Mbomou</option><option>Nana-Mambere</option><option>Ombella-M'Poko</option><option>Ouaka</option><option>Ouham</option><option>Ouham-Pende</option><option>Vakaga</option>