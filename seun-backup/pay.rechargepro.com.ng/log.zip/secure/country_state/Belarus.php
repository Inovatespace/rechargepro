<option>Brest</option>
<option>Gomel</option>
<option>Grodno</option>
<option>Mogilev</option>
<option>Minsk Region</option>
<option>Vitebsk Region</option>
<option>Minsk City</option>