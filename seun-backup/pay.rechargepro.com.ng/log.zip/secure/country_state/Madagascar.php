<option>Antananarivo</option>
<option>Antsiranana</option>
<option>Fianarantsoa</option>
<option>Mahajanga</option>
<option>Toamasina</option>
<option>Toliara</option>