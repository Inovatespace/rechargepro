<option>Bumthang</option>
<option>Chukha (Chhukha)</option>
<option>Dagana</option>
<option>Gasa</option>
<option>Haa</option>
<option>Lhuntse</option>
<option>Mongar</option>
<option>Paro</option>
<option>Pemagatshel (Pemagatsel)</option>
<option>Punakha</option>
<option>Samdrup Jongkhar</option>
<option>Samtse (Samchi)</option>
<option>Sarpang (Sarbhang)</option>
<option>Thimphu</option>
<option>Trashigang (Tashigang)</option>
<option>Trashiyangtse</option>
<option>Trongsa (Tongsa)</option>
<option>Tsirang (Chirang)</option>
<option>Wangdue Phodrang (Wangdi Phodrang)</option>
<option>Zhemgang (Shemgang)</option>