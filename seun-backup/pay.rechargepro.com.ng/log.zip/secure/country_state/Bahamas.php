<option>Acklins</option>
<option>Berry Islands</option>
<option>Bimini</option>
<option>Black Point, Exuma</option>
<option>Cat Island</option>
<option>Central Abaco</option>
<option>Central Andros</option>
<option>Central Eleuthera</option>
<option>City of Freeport, Grand Bahama</option>
<option>Crooked Island</option>
<option>East Grand Bahama</option>
<option>Exuma</option>
<option>Grand Cay, Abaco</option>
<option>Harbour Island, Eleuthera</option>
<option>Hope Town, Abaco</option>
<option>Inagua</option>
<option>Long Island</option>
<option>Mangrove Cay, Andros</option>
<option>Mayaguana</option>
<option>Moore's Island, Abaco</option>
<option>North Abaco</option>
<option>North Andros</option>
<option>North Eleuthera</option>
<option>Ragged Island</option>
<option>Rum Cay</option>
<option>San Salvador</option>
<option>South Abaco</option>
<option>South Andros</option>
<option>South Eleuthera</option>
<option>Spanish Wells, Eleuthera</option>
<option>West Grand Bahama</option>
<option>Green Turtle Cay</option>
<option>New Providence</option>