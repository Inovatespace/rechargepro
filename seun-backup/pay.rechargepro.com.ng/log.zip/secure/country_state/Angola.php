<option>Bengo</option>
<option>Benguela</option>
<option>Bie</option>
<option>Cabinda</option>
<option>Cuando Cubango</option>
<option>Cuanza Norte</option>
<option>Cuanza Sul</option>
<option>Cunene</option>
<option>Huambo</option>
<option>Huila</option>
<option>Luanda</option>
<option>Lunda Norte</option>
<option>Lunda Sul</option>
<option>Malanje</option>
<option>Moxico</option>
<option>Namibe</option>
<option>Uige</option>
<option>Zaire</option>