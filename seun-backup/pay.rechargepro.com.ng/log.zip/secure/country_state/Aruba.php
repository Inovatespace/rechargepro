<option>Noord / Tanki Leendert</option>
<option>Oranjestad West</option>
<option>Oranjestad Oost</option>
<option>Paradera</option>
<option>San Nicolas Noord</option>
<option>San Nicolas Zuid</option>
<option>Santa Cruz</option>
<option>Savaneta</option>
<option>Total Aruba</option>