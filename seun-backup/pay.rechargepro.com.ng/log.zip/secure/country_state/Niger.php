<option>Agadez</option>
<option>Diffa</option>
<option>Dosso</option>
<option>Maradi</option>
<option>Tahoua</option>
<option>Tillaberi</option>
<option>Zinder</option>
<option>Niamey</option>