<option>Central</option>
<option>Coast</option>
<option>Eastern</option>
<option>Nairobi</option>
<option>North Eastern</option>
<option>Nyanza</option>
<option>Rift Valley</option>
<option>Western</option>