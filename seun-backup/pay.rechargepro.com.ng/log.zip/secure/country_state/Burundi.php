<option>Bubanza</option>
<option>Bujumbura Mairie</option>
<option>Bujumbura Rural</option>
<option>Bururi</option>
<option>Cankuzo</option>
<option>Cibitoke</option>
<option>Gitega</option>
<option>Karuzi</option>
<option>Kayanza</option>
<option>Kirundo</option>
<option>Makamba</option>
<option>Muramvya</option>
<option>Muyinga</option>
<option>Mwaro</option>
<option>Ngozi</option>
<option>Rutana</option>
<option>Ruyigi</option>