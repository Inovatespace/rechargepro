<option>Saint George</option>
<option>Saint John</option>
<option>Saint Mary</option>
<option>Saint Paul</option>
<option>Saint Peter</option>
<option>Saint Philip</option>
<option>Barbuda</option>
<option>Redonda</option>