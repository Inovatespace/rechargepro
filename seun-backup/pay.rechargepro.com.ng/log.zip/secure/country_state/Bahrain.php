<option>Al Hidd</option>
<option>Manama</option>
<option>Western Region</option>
<option>Central Region</option>
<option>Northern Region</option>
<option>Muharraq</option>
<option>Rifa and Southern Region</option>
<option>Jidd Haffs</option>
<option>Hamad Town</option>
<option>Isa Town</option>
<option>Hawar Islands</option>
<option>Sitra</option>