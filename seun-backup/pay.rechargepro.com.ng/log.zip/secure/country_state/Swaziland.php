<option>Hhohho</option>
<option>Lubombo</option>
<option>Manzini</option>
<option>Shiselweni</option>