127.0.0.1 - 05/31/19 13:01:41 @ Exception # SQLSTATE[42000]: Syntax error or access violation: 1110 Column 'thirdPartycode' specified twice * C:\xampp\htdocs\dipo\engine\class\engine.php $ 1417 |
127.0.0.1 - 05/31/19 21:47:30 @ Notice # Undefined variable: engine * C:\xampp\htdocs\dipo\theme\classic\pages\call\utility.php $ 207 |
127.0.0.1 - 05/31/19 21:47:30 @ Notice # Undefined index: args * C:\xampp\htdocs\dipo\engine\class\Logger.php $ 120 |
127.0.0.1 - 05/31/19 21:47:30 @ Notice # array_map(): Argument #2 should be an array * C:\xampp\htdocs\dipo\engine\class\Logger.php $ 120 |
127.0.0.1 - 05/31/19 21:47:30 @ Notice # implode(): Invalid arguments passed * C:\xampp\htdocs\dipo\engine\class\Logger.php $ 125 |
127.0.0.1 - 05/31/19 21:47:30 @ Exception # Call to a member function db_query() on null * C:\xampp\htdocs\dipo\theme\classic\pages\call\utility.php $ 207 |
