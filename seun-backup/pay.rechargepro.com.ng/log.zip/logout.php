<?php
include ('engine.autoloader.php');
session_destroy();
header("location:home"); exit;
?>