RewriteEngine on

<Files ~ "\.php$">
Order allow,deny
Deny from all
</Files>

