
<style type="text/css">


</style>
<div style="border-top: solid 1px #CCCCCC;" class="profilebg">
<div class="sitewidth" style="margin: 0px auto; padding: 20px 0px;">
		<footer >
        
        
   <section class="footer-Content">
        <div style="overflow: hidden;">
          <div class="row">
            <div style="float: left; width:30%;">
              <h3 style="font-size:20px; font-weight: 700; color: #263238;">QuickPay</h3>
              <div class="textwidget">
                <p>QuickPay offers you quick and reliable vending solutions.</p>
              </div>
              <a class="facebook" href="#"><i style="font-size:30px;" class="fab fa-facebook"></i></a>
               <a class="twitter" href="#"><i style="font-size:30px;" class="fab fa-twitter fax2"></i></a>
               <a class="linkedin" href="#"><i style="font-size:30px;" class="fab fa-linkedin"></i></a>
                <a class="google-plus" href="#"><i style="font-size:30px;" class="fab fa-google"></i></a>
               
            </div>
            <div style="float: left; width:35%;">
              <div class="widget">
                <h3 class="block-title">Partners</h3>
                <a href="#"><img src="/theme/classic/images/new-header-logo.png"  height="100px" style="margin-right: 10px;" alt=""></a>
                <a href="#"><img src="/theme/classic/images/aedc.png" height="100px" alt=""></a>
                <!-- <ul class="menu">
                  <li><a href="#">Service</a></li>
                  <li><a href="#">Wishlist</a></li>
                  <li><a href="#">FAQ</a></li>
                  <li><a href="#">Advance Sarch</a></li>
                  <li><a href="#">Site Map</a></li>
                </ul> -->
              </div>
            </div>
            
            
			<div style="float: right; width:30%;">
              <div class="widget">
                <h3 class="block-title">Contact Us</h3>
               
                  <div>
                    <strong>Phone :</strong> <span>0809 386 9012 </span>
                  </div>
                  <div>
                    <strong>E-mail :</strong> <span><a href="#">info@quickpay.com.ng</a></span>
                  </div>
               
              </div>
            </div>
          </div>
        </div>
      </section>
		</footer>
        
        
        
        </div>
        </div>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        



<div style="background-color: white; text-align:center; padding:20px; font-size:90%;">Copyright @ QUICKPAY 2019. All right reservd
<div><a href="privacy">Privacy Policy</a> | <a href="terms">Terms and  Condition</a></div>
</div>



